import numpy as npy
import matplotlib.pyplot as plt
import skfuzzy as fuzz
from skfuzzy import control as cl

temp=cl.Antecedent(npy.arange(0,61,1),'temperature')                  
temp['Extremely Low']=fuzz.trimf(temp.universe, [0, 0, 12])           
temp['Low']=fuzz.trimf(temp.universe, [11, 12, 13])
temp['Medium']=fuzz.trimf(temp.universe, [12, 18.5, 25])
temp['High']=fuzz.trimf(temp.universe, [23, 31.5, 40])
temp['Extremely High']=fuzz.trapmf(temp.universe, [38, 42, 67,100])

temp.view()

wind=cl.Antecedent(npy.arange(0,5.1,0.1),'wind speed')             
wind['slow']=fuzz.trimf(wind.universe, [0, 0, 2])                   
wind['medium']=fuzz.trimf(wind.universe, [1.5, 2.25, 3])
wind['fast']=fuzz.trapmf(wind.universe, [3, 4, 11,23])

wind.view()

prob=cl.Consequent(npy.arange(0,1.1,0.1),'chance of molten ice cream')    
prob['low'] = fuzz.trimf(prob.universe, [0, 0, 0.3])                     
prob['medium'] = fuzz.trimf(prob.universe, [0.3, 0.5, 0.75]) 
prob['high'] = fuzz.trimf(prob.universe, [0.75, 1, 1])

prob.view()

cnd1 = cl.Rule(temp['Extremely Low'], prob['low'])
cnd2 = cl.Rule(temp['Low'] & wind['slow'], prob['low'])                  
cnd3 = cl.Rule(temp['Low'] & wind['medium'], prob['medium'])             
cnd4 = cl.Rule(temp['Low'] & wind['fast'], prob['medium'])
cnd5 = cl.Rule(temp['Medium'] & wind['slow'], prob['low'])
cnd6 = cl.Rule(temp['Medium'] & wind['medium'], prob['medium'])
cnd7 = cl.Rule(temp['Medium'] & wind['fast'], prob['high'])
cnd8 = cl.Rule(temp['High'] & wind['slow'], prob['medium'])
cnd9 = cl.Rule(temp['High'] & wind['medium'], prob['high'])
cnd10 = cl.Rule(temp['High'] & wind['fast'], prob['high'])
cnd11 = cl.Rule(temp['Extremely High'], prob['high'])


prob_cl = cl.ControlSystem([cnd1,cnd2,cnd3,cnd4,cnd5,cnd6,cnd7,cnd8,cnd9,cnd10,cnd11])
probability= cl.ControlSystemSimulation(prob_cl)

probability.input['temperature'] = 10                    
probability.input['wind speed'] = 1.7
probability.compute()
print(probability.output['probability of molten ice cream'])
prob.view(sim=probability)
plt.show()